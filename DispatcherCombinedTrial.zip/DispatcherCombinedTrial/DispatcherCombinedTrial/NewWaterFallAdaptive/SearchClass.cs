﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
//using Microsoft.SharePoint.Client;
using System.Text;
using System.Security;
using Microsoft.SharePoint.Client;

namespace NewWaterFallAdaptive
{
    public class SearchClass
    {
        public Web web;
        public ListItemCollection courseDetails;
        public ListItemCollection modeDetails;
        public ListItemCollection locationDetails;
        public ListItemCollection dateTimeDetails;
        public ListItemCollection searchQueryDetails;
        public ClientContext clientContext;
        //static string courseNameQuery;
        static string modeQuery;
        static string locationQuery;
        static string dateQuery;
        //static string timeQuery;
        //private string datetimeQuery;
        public StringBuilder dynamicQuery;

        public ClientContext GetSPContext(string siteUrl, string userName, string userPassword)
        {
            //tenantUserPassword = "Collab60@abc9";
            //siteUrl = "https://infyakash.sharepoint.com/sites/Solutionssite/";


            clientContext = new ClientContext(siteUrl);
            
            clientContext.Credentials = new SharePointOnlineCredentials(userName, userPassword);
            return clientContext;
        }
        
        public string GetCourseNameQuery(string searchCourseName)
        {
            string courseNameQuery = "<Contains><FieldRef Name='Title' /><Value Type='Text'>" + searchCourseName + "</Value></Contains>";
            return courseNameQuery;            
        }
        public string GetLocationQuery(string searchLocation)
        {
            string locationQuery = "<Contains><FieldRef Name='Location' /><Value Type='Text'>" + searchLocation + "</Value></Contains>";
            return locationQuery;
        }

        public ListItemCollection SearchCourse(ClientContext ctx,string courseNameQuery)
        {
            try
            {                
                web = ctx.Web;
                ctx.Load(web);
                if (ctx.HasPendingRequest)
                {
                    ctx.ExecuteQueryAsync().Wait();
                }

                List list = web.Lists.GetByTitle("Trainings");
                CamlQuery query = new CamlQuery();

                dynamicQuery = new StringBuilder("<View><Query><Where>");
                dynamicQuery.Append(courseNameQuery);
                dynamicQuery.Append("</Where></Query></View>");                
                query.ViewXml = dynamicQuery.ToString();
                searchQueryDetails = list.GetItems(query);
                clientContext.Load(searchQueryDetails);
                if (ctx.HasPendingRequest)
                {
                    ctx.ExecuteQueryAsync().Wait();
                }
                courseNameQuery = "";
                modeQuery = "";
                locationQuery = "";
                dateQuery = "";

                
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }
            return searchQueryDetails;
        }

    }
}