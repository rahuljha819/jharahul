﻿using Microsoft.Bot.Builder;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Builder.Dialogs.Choices;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Threading;
using System.Threading.Tasks;

namespace NewWaterFallAdaptive.Dialogs.Forms
{
    public class LicenseRequestForm : ComponentDialog
    {
        private readonly IStatePropertyAccessor<User> _userAccessor;

        public LicenseRequestForm(UserState userAccessor) : base(nameof(LicenseRequestForm))
        {
            _userAccessor = userAccessor.CreateProperty<User>("User");
            var waterfallSteps = new WaterfallStep[]
            {
                LicenseRequestAsync,
                LicenseEmailIDAsync,
                LicenseToAddAsync,
                LicenseToRemoveAsync,                
                BusinessJustificationAsync,
                ConfirmStepAsync,
                SummaryStepAsync,
            };

            AddDialog(new WaterfallDialog(nameof(WaterfallDialog), waterfallSteps));
            AddDialog(new TextPrompt(nameof(TextPrompt)));
            AddDialog(new NumberPrompt<int>(nameof(NumberPrompt<int>)));
            AddDialog(new ChoicePrompt(nameof(ChoicePrompt)));
            AddDialog(new ConfirmPrompt(nameof(ConfirmPrompt)));

            InitialDialogId = nameof(WaterfallDialog);
        }

        private static async Task<DialogTurnResult> LicenseRequestAsync(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {
            return await stepContext.PromptAsync(nameof(ChoicePrompt), new PromptOptions
            {
                Prompt = MessageFactory.Text("Please choose your option for License request."),
                Choices = ChoiceFactory.ToChoices(new List<string> { "Assign License", "Optimize License", "Remove License" }),
            }, cancellationToken);
        }
        private static async Task<DialogTurnResult> LicenseEmailIDAsync(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {
            stepContext.Values["LicenseRequest"] = ((FoundChoice)stepContext.Result).Value;

            return await stepContext.PromptAsync(nameof(TextPrompt), new PromptOptions
            {
                Prompt = MessageFactory.Text("Please provide User Email ID")
            }, cancellationToken);
        }
        private static async Task<DialogTurnResult> LicenseToAddAsync(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {
            stepContext.Values["LicenseEmailID"] = (string)stepContext.Result;
            if (((string)stepContext.Values["LicenseRequest"] == "Assign License") || ((string)stepContext.Values["LicenseRequest"] == "Optimize License"))
            {    
                return await stepContext.PromptAsync(nameof(ChoicePrompt), new PromptOptions
                {
                    Prompt = MessageFactory.Text("Please choose license to add."),
                    Choices = ChoiceFactory.ToChoices(new List<string> { "Power Apps And Logic Flows", "Power BI Pro", "Office 365 Enterprise E3", "Microsoft Flow(Free)", "Microsoft Power Apps Plan 2 Trial", "Power BI(Free)" }),
                }, cancellationToken);
            }
            else
            {
                return await stepContext.NextAsync(stepContext, cancellationToken);
            }
        }

        private static async Task<DialogTurnResult> LicenseToRemoveAsync(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {
            if((string)stepContext.Values["LicenseRequest"] == "Assign License")
            {
                stepContext.Values["LicenseToAdd"] = ((FoundChoice)stepContext.Result).Value;
                return await stepContext.NextAsync(stepContext, cancellationToken);
            }
            if (((string)stepContext.Values["LicenseRequest"] == "Remove License") || ((string)stepContext.Values["LicenseRequest"] == "Optimize License"))
            {
                return await stepContext.PromptAsync(nameof(ChoicePrompt), new PromptOptions
                {
                    Prompt = MessageFactory.Text("Please choose license to remove."),
                    Choices = ChoiceFactory.ToChoices(new List<string> { "Power Apps And Logic Flows", "Power BI Pro", "Office 365 Enterprise E3", "Microsoft Flow(Free)", "Microsoft Power Apps Plan 2 Trial", "Power BI(Free)" }),
                }, cancellationToken);
            }
            else
            {
                return await stepContext.NextAsync(stepContext, cancellationToken);
            }
        }
        private static async Task<DialogTurnResult> BusinessJustificationAsync(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {
            if (((string)stepContext.Values["LicenseRequest"] == "Remove License") || ((string)stepContext.Values["LicenseRequest"] == "Optimize License"))
            {
                stepContext.Values["LicenseToRemove"] = ((FoundChoice)stepContext.Result).Value;
            }
                

            return await stepContext.PromptAsync(nameof(TextPrompt), new PromptOptions
            {
                Prompt = MessageFactory.Text("Please enter Business Justification.")
            }, cancellationToken);
        }
        private static async Task<DialogTurnResult> ConfirmStepAsync(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {
            stepContext.Values["MailboxAccessBusinessJustification"] = (string)stepContext.Result;

            return await stepContext.PromptAsync(nameof(ConfirmPrompt), new PromptOptions
            {
                Prompt = MessageFactory.Text("Would you like to Confirm?")
            }, cancellationToken);
        }

        private async Task<DialogTurnResult> SummaryStepAsync(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {
            if ((bool)stepContext.Result)
            {
                var user = await _userAccessor.GetAsync(stepContext.Context, () => new User(), cancellationToken);

                user.LicenseRequest = (string)stepContext.Values["LicenseRequest"];
                user.LicenseEmailID = (string)stepContext.Values["LicenseEmailID"];
                if ((string)stepContext.Values["LicenseToAdd"] != null)
                {
                    user.LicenseToAdd = (string)stepContext.Values["LicenseToAdd"];
                }
                else
                {
                    user.LicenseToAdd = "";
                }
                if ((string)stepContext.Values["LicenseToRemove"] != null)
                {
                    user.LicenseToRemove = (string)stepContext.Values["LicenseToRemove"];
                }
                else
                {
                    user.LicenseToRemove = "";
                }
                user.BusinessJustification = (string)stepContext.Values["MailboxAccessBusinessJustification"];

                string finalValue = "";

                string baseUrl = ""; //SNIntergationAPI;
                HttpWebRequest request = (HttpWebRequest)WebRequest.Create(baseUrl);
                request.ContentType = "application/json";
                request.Method = "POST";
                
                if (user.LicenseRequest == "Assign License")
                {
                    user.LicenseRequest = "assign_license";
                }
                else if (user.LicenseRequest == "Optimize License")
                {
                    user.LicenseRequest = "optimize_license";
                }
                else if (user.LicenseRequest == "Remove License")
                {
                    user.LicenseRequest = "remove_license";
                }
                
                if (user.LicenseToAdd == "Power Apps And Logic Flows")
                {
                    user.LicenseToAdd = "powerapps_and_logic_flows";
                }
                else if (user.LicenseToAdd == "Power BI Pro")
                {
                    user.LicenseToAdd = "power_bi_pro";
                }
                else if (user.LicenseToAdd == "Office 365 Enterprise E3")
                {
                    user.LicenseToAdd = "office_365_enterprise_e3";
                }
                else if (user.LicenseToAdd == "Microsoft Flow(Free)")
                {
                    user.LicenseToAdd = "microsoft_flow_free";
                }
                else if (user.LicenseToAdd == "Microsoft Power Apps Plan 2 Trial")
                {
                    user.LicenseToAdd = "microsoft_powerapps_plan_2_trial";
                }
                else if (user.LicenseToAdd == "Power BI(Free)")
                {
                    user.LicenseToAdd = "power_bi_free";
                }

               // var newLicenseToRemove = LicenseRequestFormData.licenseToRemove.ToString();
                if (user.LicenseToRemove == "Power Apps And Logic Flows")
                {
                    user.LicenseToRemove = "powerapps_and_logic_flows";
                }
                else if (user.LicenseToRemove == "Power BI Pro")
                {
                    user.LicenseToRemove = "power_bi_pro";
                }
                else if (user.LicenseToRemove == "Office 365 Enterprise E3")
                {
                    user.LicenseToRemove = "office_365_enterprise_e3";
                }
                else if (user.LicenseToRemove == "Microsoft Flow(Free)")
                {
                    user.LicenseToRemove = "microsoft_flow_free";
                }
                else if (user.LicenseToRemove == "Microsoft Power Apps Plan 2 Trial")
                {
                    user.LicenseToRemove = "microsoft_powerapps_plan_2_trial";
                }
                else if (user.LicenseToRemove == "Power BI(Free)")
                {
                    user.LicenseToRemove = "power_bi_free";
                }


                string currentDT = DateTime.UtcNow.ToString("MM/dd/yyyy h:mm tt");

                string json = "{\"item_name\":\"" + "License" + "\","
                    + "\"license_request\":\"" + user.LicenseRequest + "\","
                    + "\"user_email_id\":\"" + user.LicenseEmailID + "\","
                    + "\"license_to_add\":\"" + user.LicenseToAdd + "\","
                    + "\"license_to_remove\":\"" + user.LicenseToRemove + "\","
                    + "\"business_justification\":\"" + user.BusinessJustification + "\""
                    + "}";
                //await context.PostAsync(json);

                using (var streamWriter = new StreamWriter(request.GetRequestStream()))
                {
                    streamWriter.Write(json);
                }

                using (var response = (HttpWebResponse)request.GetResponse())
                {
                    string responseValue = "";

                    if (response.StatusCode != HttpStatusCode.Created)
                    {
                        var message = String.Format("Request failed. Received HTTP {0}", response.StatusCode);
                        throw new ApplicationException(message);
                    }

                    // grab the response
                    using (var responseStream = response.GetResponseStream())
                    {
                        if (responseStream != null)
                            using (var reader = new StreamReader(responseStream))
                            {
                                responseValue = reader.ReadToEnd();
                            }
                    }
                    JObject obj = JObject.Parse(responseValue);

                    var requestValues = JObject.FromObject(obj).ToObject<Dictionary<string, object>>();

                    foreach (KeyValuePair<string, object> reqVal in requestValues)
                    {
                        var requestObject = JObject.FromObject(requestValues).ToObject<Dictionary<string, string>>();
                        foreach (KeyValuePair<string, string> reqValue in requestObject)
                        {
                            finalValue = reqValue.Value;
                        }
                    }
                }

                //await context.PostAsync("Thank you for the inputs. Your Ticket No. is: " + finalValue);


                await stepContext.Context.SendActivityAsync(MessageFactory.Text("Thank you for the inputs. Your Ticket No. is: " + finalValue));

                //await stepContext.Context.SendActivityAsync(MessageFactory.Text(user.RequestOptions+ user.SiteName + user.SiteTemplate + user.ParentSiteURL + user.BusinessJustification));
            }
            else
            {
                await stepContext.Context.SendActivityAsync(MessageFactory.Text("Request Not Confirmed."));
            }
            return await stepContext.EndDialogAsync(cancellationToken: cancellationToken);

        }
    }
}
