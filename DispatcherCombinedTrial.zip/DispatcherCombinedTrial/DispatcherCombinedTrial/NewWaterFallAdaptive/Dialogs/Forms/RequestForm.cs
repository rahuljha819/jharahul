// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License.
//
// Generated with Bot Builder V4 SDK Template for Visual Studio CoreBot v4.3.0

using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Bot.Builder;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Builder.Dialogs.Choices;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Microsoft.Recognizers.Text.DataTypes.TimexExpression;
using Newtonsoft.Json.Linq;

namespace NewWaterFallAdaptive.Dialogs.Forms
{
    public class RequestForm : ComponentDialog
    {
        private readonly IStatePropertyAccessor<User> _userAccessor;

        public RequestForm(UserState userState): base(nameof(RequestForm))
        {
            _userAccessor = userState.CreateProperty<User>("User");

            var waterfallSteps = new WaterfallStep[]
            {
                RequestOptionsAsync,
                SiteNameAsync,
                SiteTemplateAsync,
                ParentSiteURLAndSiteOwnerAsync,
                BusinessJustificationAsync,
                ConfirmStepAsync,
                SummaryStepAsync,
            };

            AddDialog(new WaterfallDialog(nameof(WaterfallDialog), waterfallSteps));
            AddDialog(new TextPrompt(nameof(TextPrompt)));
            AddDialog(new NumberPrompt<int>(nameof(NumberPrompt<int>)));
            AddDialog(new ChoicePrompt(nameof(ChoicePrompt)));
            AddDialog(new ConfirmPrompt(nameof(ConfirmPrompt)));

            InitialDialogId = nameof(WaterfallDialog);
        }

        private static async Task<DialogTurnResult> RequestOptionsAsync(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {
            return await stepContext.PromptAsync(nameof(ChoicePrompt), new PromptOptions
            {
                Prompt = MessageFactory.Text("Please choose your option for Site Provisioning request."),
                Choices = ChoiceFactory.ToChoices(new List<string> { "SiteCollection", "SubSite" }),
            }, cancellationToken);
        }

        private static async Task<DialogTurnResult> SiteNameAsync(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {
            stepContext.Values["RequestOptions"] = ((FoundChoice)stepContext.Result).Value;
            //Console.WriteLine("First Choice: " + ((FoundChoice)stepContext.Result).Value);

            return await stepContext.PromptAsync(nameof(TextPrompt), new PromptOptions
            {
                Prompt = MessageFactory.Text("Please enter Site Name")
            }, cancellationToken);
        }

        private static async Task<DialogTurnResult> SiteTemplateAsync(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {
            stepContext.Values["SiteName"] = (string)stepContext.Result;

            return await stepContext.PromptAsync(nameof(ChoicePrompt), new PromptOptions
            {
                Prompt = MessageFactory.Text("Please choose Site Template."),
                Choices = ChoiceFactory.ToChoices(new List<string> { "Blog", "ProjectSite", "CommunitySite", "TeamSite"}),
            }, cancellationToken);
        }

        private static async Task<DialogTurnResult> ParentSiteURLAndSiteOwnerAsync(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {
            stepContext.Values["SiteTemplate"] = ((FoundChoice)stepContext.Result).Value;

            if((string)stepContext.Values["RequestOptions"] == "SubSiteCreation")
            {
                return await stepContext.PromptAsync(nameof(TextPrompt), new PromptOptions
                {
                    Prompt = MessageFactory.Text("Please enter Parent Site URL.")
                }, cancellationToken);
            }
            else
            {
                return await stepContext.PromptAsync(nameof(TextPrompt), new PromptOptions
                {
                    Prompt = MessageFactory.Text("Please enter Site Owner.")
                }, cancellationToken);
            }
            
        }

        private static async Task<DialogTurnResult> BusinessJustificationAsync(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {
            if((string)stepContext.Values["RequestOptions"] == "SubSiteCreation")
            {
                stepContext.Values["ParentSiteURL"] = (string)stepContext.Result;
            }
            else
            {
                stepContext.Values["SiteOwner"] = (string)stepContext.Result;
            }

            return await stepContext.PromptAsync(nameof(TextPrompt), new PromptOptions
            {
                Prompt = MessageFactory.Text("Please enter Business Justification.")
            }, cancellationToken);
        }

        private static async Task<DialogTurnResult> ConfirmStepAsync(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {
            stepContext.Values["BusinessJustification"] = (string)stepContext.Result;

            return await stepContext.PromptAsync(nameof(ConfirmPrompt), new PromptOptions
            {
                Prompt = MessageFactory.Text("Would you like to Confirm?")
            }, cancellationToken);
        }

        private async Task<DialogTurnResult> SummaryStepAsync(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {
            if ((bool)stepContext.Result)
            {
                var user = await _userAccessor.GetAsync(stepContext.Context, () => new User(), cancellationToken);

                user.RequestOptions = (string)stepContext.Values["RequestOptions"];
                user.SiteName = (string)stepContext.Values["SiteName"];
                if ((string)stepContext.Values["SiteTemplate"] != null)
                {
                    user.SiteTemplate = (string)stepContext.Values["SiteTemplate"];
                }
                else
                {
                    user.SiteTemplate = "";
                }
                

                if(user.RequestOptions == "SubSiteCreation")
                {
                    user.ParentSiteURL = (string)stepContext.Values["ParentSiteURL"];
                }
                else
                {
                    user.SiteOwner = (string)stepContext.Values["SiteOwner"];
                }
                
                user.BusinessJustification = (string)stepContext.Values["BusinessJustification"];

                string finalValue = "";

                string baseUrl = ""; //SNIntergationAPI;
                HttpWebRequest request = (HttpWebRequest)WebRequest.Create(baseUrl);
                request.ContentType = "application/json";
                request.Method = "POST";
                
                if (user.RequestOptions == "SiteCollectionCreation")
                {
                    user.RequestOptions = "site_collection_creation";
                }
                else if (user.RequestOptions == "SubSiteCreation")
                {
                    user.RequestOptions = "sub_site_creation";
                }
                
                if (user.SiteTemplate == "Blog")
                {
                    user.SiteTemplate = "BLOG#0";
                }
                else if (user.SiteTemplate == "ProjectSite")
                {
                    user.SiteTemplate = "PROJECTSITE#0";
                }
                else if (user.SiteTemplate == "CommunitySite")
                {
                    user.SiteTemplate = "COMMUNITY#0";
                }
                else if (user.SiteTemplate == "TeamSite")
                {
                    user.SiteTemplate = "STS#0";
                }               

                string json = "{\"item_name\":\"" + "Site Provisioning" + "\","
                + "\"request_type\":\"" + user.RequestOptions + "\","
                + "\"site_name\":\"" + user.SiteName + "\","
                + "\"site_template\":\"" + user.SiteTemplate + "\","
                + "\"target\":\"" + "o_365" + "\","
                + "\"expected_start_date\":\"" + "" + "\","
                + "\"parent_site_URL\":\"" + user.ParentSiteURL + "\","
                + "\"site_owner\":\"" + user.SiteOwner + "\","
                + "\"site_description\":\"" + "" + "\","
                + "\"additional_site_owners\":\"" + "" + "\","
                + "\"site_members\":\"" + "" + "\","
                + "\"site_viewers\":\"" + "" + "\","
                + "\"site_contains_sensitive_information\":\"" + "" + "\","
                + "\"additional_information\":\"" + "" + "\","
                + "\"business_justification\":\"" + user.BusinessJustification + "\""
                + "}";

                using (var streamWriter = new StreamWriter(request.GetRequestStream()))
                {
                    streamWriter.Write(json);
                }

                using (var response = (HttpWebResponse)request.GetResponse())
                {
                    string responseValue = "";

                    if (response.StatusCode != HttpStatusCode.Created)
                    {
                        var message = String.Format("Request failed. Received HTTP {0}", response.StatusCode);
                        throw new ApplicationException(message);
                    }

                    // grab the response
                    using (var responseStream = response.GetResponseStream())
                    {
                        if (responseStream != null)
                            using (var reader = new StreamReader(responseStream))
                            {
                                responseValue = reader.ReadToEnd();
                            }

                    }
                    JObject obj = JObject.Parse(responseValue);

                    var requestValues = JObject.FromObject(obj).ToObject<Dictionary<string, object>>();

                    foreach (KeyValuePair<string, object> reqVal in requestValues)
                    {
                        var requestObject = JObject.FromObject(requestValues).ToObject<Dictionary<string, string>>();
                        foreach (KeyValuePair<string, string> reqValue in requestObject)
                        {
                            finalValue = reqValue.Value;
                        }
                    }
                }

               // await context.PostAsync("Thank you for the inputs. Your Ticket No. is: " + finalValue);

                await stepContext.Context.SendActivityAsync(MessageFactory.Text("Thank you for the inputs. Your Ticket No. is: " + finalValue));

                //await stepContext.Context.SendActivityAsync(MessageFactory.Text(user.RequestOptions+ user.SiteName + user.SiteTemplate + user.ParentSiteURL + user.BusinessJustification));
            }
            else
            {
                await stepContext.Context.SendActivityAsync(MessageFactory.Text("Request Not Confirmed."));
            }
            return await stepContext.EndDialogAsync(cancellationToken: cancellationToken);

        }

    }
}
