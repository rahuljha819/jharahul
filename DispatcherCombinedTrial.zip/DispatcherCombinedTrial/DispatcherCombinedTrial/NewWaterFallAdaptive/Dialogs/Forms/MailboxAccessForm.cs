﻿using Microsoft.Bot.Builder;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Builder.Dialogs.Choices;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Threading;
using System.Threading.Tasks;

namespace NewWaterFallAdaptive.Dialogs.Forms
{
    public class MailboxAccessForm : ComponentDialog
    {
        private readonly IStatePropertyAccessor<User> _userAccessor;
        public MailboxAccessForm(UserState userState) : base(nameof(MailboxAccessForm))
        {
            _userAccessor = userState.CreateProperty<User>("User");

            var waterfallSteps = new WaterfallStep[]
            {
                AddOrRemoveAccessAsync,
                MailboxEmailAsync,
                UserEmailAsync,
                TypeOfAccessAsync,
                BusinessJustificationAsync,
                ConfirmStepAsync,
                SummaryStepAsync,
            };

            AddDialog(new WaterfallDialog(nameof(WaterfallDialog), waterfallSteps));
            AddDialog(new TextPrompt(nameof(TextPrompt)));
            AddDialog(new NumberPrompt<int>(nameof(NumberPrompt<int>)));
            AddDialog(new ChoicePrompt(nameof(ChoicePrompt)));
            AddDialog(new ConfirmPrompt(nameof(ConfirmPrompt)));

            InitialDialogId = nameof(WaterfallDialog);
        }

        private static async Task<DialogTurnResult> AddOrRemoveAccessAsync(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {
            return await stepContext.PromptAsync(nameof(ChoicePrompt), new PromptOptions
            {
                Prompt = MessageFactory.Text("Do you want to Add user access or Remove user access on Mailbox?"),
                Choices = ChoiceFactory.ToChoices(new List<string> { "Add User Access", "Remove User Access" }),
            }, cancellationToken);
        }
        private static async Task<DialogTurnResult> MailboxEmailAsync(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {
            stepContext.Values["AddOrRemoveFromMailboxAccess"] = ((FoundChoice)stepContext.Result).Value;
            //Console.WriteLine("First Choice: " + ((FoundChoice)stepContext.Result).Value);

            return await stepContext.PromptAsync(nameof(TextPrompt), new PromptOptions
            {
                Prompt = MessageFactory.Text("Please enter the Mailbox Email.")
            }, cancellationToken);
        }

        private static async Task<DialogTurnResult> UserEmailAsync(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {
            stepContext.Values["MailboxAccessMailboxEmail"] = (string)stepContext.Result;

            return await stepContext.PromptAsync(nameof(TextPrompt), new PromptOptions
            {
                Prompt = MessageFactory.Text("Please enter the User Email.")
            }, cancellationToken);
        }
        private static async Task<DialogTurnResult> TypeOfAccessAsync(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {
            stepContext.Values["MailboxAccessEmailAddress"] = (string)stepContext.Result;

            return await stepContext.PromptAsync(nameof(ChoicePrompt), new PromptOptions
            {
                Prompt = MessageFactory.Text("Please choose the access type."),
                Choices = ChoiceFactory.ToChoices(new List<string> { "Full Access", "Read" }),
            }, cancellationToken);
        }

        private static async Task<DialogTurnResult> BusinessJustificationAsync(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {
            stepContext.Values["MailboxAccessTypeOfAccess"] = ((FoundChoice)stepContext.Result).Value;

            return await stepContext.PromptAsync(nameof(TextPrompt), new PromptOptions
            {
                Prompt = MessageFactory.Text("Please enter Business Justification.")
            }, cancellationToken);
        }
        private static async Task<DialogTurnResult> ConfirmStepAsync(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {
            stepContext.Values["MailboxAccessBusinessJustification"] = (string)stepContext.Result;

            return await stepContext.PromptAsync(nameof(ConfirmPrompt), new PromptOptions
            {
                Prompt = MessageFactory.Text("Would you like to Confirm?")
            }, cancellationToken);
        }
        private async Task<DialogTurnResult> SummaryStepAsync(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {
            if ((bool)stepContext.Result)
            {
                var user = await _userAccessor.GetAsync(stepContext.Context, () => new User(), cancellationToken);

                user.AddOrRemoveFromMailboxAccess = (string)stepContext.Values["AddOrRemoveFromMailboxAccess"];
                user.MailboxAccessMailboxEmail = (string)stepContext.Values["MailboxAccessMailboxEmail"];
                user.MailboxAccessEmailAddress = (string)stepContext.Values["MailboxAccessEmailAddress"];
                user.MailboxAccessTypeOfAccess = (string)stepContext.Values["MailboxAccessTypeOfAccess"];
                user.BusinessJustification = (string)stepContext.Values["MailboxAccessBusinessJustification"];

                string finalValue = "";

                string baseUrl = ""; //SNIntergationAPI;
                HttpWebRequest request = (HttpWebRequest)WebRequest.Create(baseUrl);
                request.ContentType = "application/json";
                request.Method = "POST";

                // await context.PostAsync(newUserAccess);
                if (user.AddOrRemoveFromMailboxAccess == "Add User Access")
                {
                    user.AddOrRemoveFromMailboxAccess = "add_user_access";
                }
                else if (user.AddOrRemoveFromMailboxAccess == "Remove User Access")
                {
                    user.AddOrRemoveFromMailboxAccess = "remove_user_access";
                }

                //await context.PostAsync(newUserAccess);
                
                if (user.MailboxAccessTypeOfAccess == "Full Access")
                {
                    user.MailboxAccessTypeOfAccess = "full_access";
                }
                else if (user.MailboxAccessTypeOfAccess == "Read")
                {
                    user.MailboxAccessTypeOfAccess = "read";
                }

                

                string json = "{\"item_name\":\"" + "Mailbox Access" + "\","
                    + "\"user_access_options\":\"" + user.AddOrRemoveFromMailboxAccess + "\","
                    + "\"mailbox_email\":\"" + user.MailboxAccessMailboxEmail + "\","
                    + "\"user_email\":\"" + user.MailboxAccessEmailAddress + "\","
                    + "\"type_of_access\":\"" + user.MailboxAccessTypeOfAccess + "\","
                    + "\"business_justification\":\"" + user.BusinessJustification + "\""
                    + "}";
                //await context.PostAsync(json);

                using (var streamWriter = new StreamWriter(request.GetRequestStream()))
                {
                    streamWriter.Write(json);
                }

                using (var response = (HttpWebResponse)request.GetResponse())
                {
                    string responseValue = "";

                    if (response.StatusCode != HttpStatusCode.Created)
                    {
                        var message = String.Format("Request failed. Received HTTP {0}", response.StatusCode);
                        throw new ApplicationException(message);
                    }

                    // grab the response
                    using (var responseStream = response.GetResponseStream())
                    {
                        if (responseStream != null)
                            using (var reader = new StreamReader(responseStream))
                            {
                                responseValue = reader.ReadToEnd();
                            }
                    }
                    JObject obj = JObject.Parse(responseValue);

                    var requestValues = JObject.FromObject(obj).ToObject<Dictionary<string, object>>();

                    foreach (KeyValuePair<string, object> reqVal in requestValues)
                    {
                        var requestObject = JObject.FromObject(requestValues).ToObject<Dictionary<string, string>>();
                        foreach (KeyValuePair<string, string> reqValue in requestObject)
                        {
                            finalValue = reqValue.Value;
                        }
                    }
                }

                //await context.PostAsync("Thank you for the inputs. Your Ticket No. is: " + finalValue);


                await stepContext.Context.SendActivityAsync(MessageFactory.Text("Thank you for the inputs. Your Ticket No. is: " + finalValue));

                //await stepContext.Context.SendActivityAsync(MessageFactory.Text(user.RequestOptions+ user.SiteName + user.SiteTemplate + user.ParentSiteURL + user.BusinessJustification));
            }
            else
            {
                await stepContext.Context.SendActivityAsync(MessageFactory.Text("Request Not Confirmed."));
            }
            return await stepContext.EndDialogAsync(cancellationToken: cancellationToken);

        }
    }
}
