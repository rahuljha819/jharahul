﻿using Microsoft.Bot.Builder;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Builder.Dialogs.Choices;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace NewWaterFallAdaptive.Dialogs.Forms
{
    public class SharedMailboxForm : ComponentDialog
    {
        private readonly IStatePropertyAccessor<User> _userAccessor;

        public SharedMailboxForm(UserState userAccessor) : base(nameof(SharedMailboxForm))
        {
            _userAccessor = userAccessor.CreateProperty<User>("User");
            var waterfallSteps = new WaterfallStep[]
            {
               
            };

            AddDialog(new WaterfallDialog(nameof(WaterfallDialog), waterfallSteps));
            AddDialog(new TextPrompt(nameof(TextPrompt)));
            AddDialog(new NumberPrompt<int>(nameof(NumberPrompt<int>)));
            AddDialog(new ChoicePrompt(nameof(ChoicePrompt)));
            AddDialog(new ConfirmPrompt(nameof(ConfirmPrompt)));

            InitialDialogId = nameof(WaterfallDialog);
        }

        
    }
}
