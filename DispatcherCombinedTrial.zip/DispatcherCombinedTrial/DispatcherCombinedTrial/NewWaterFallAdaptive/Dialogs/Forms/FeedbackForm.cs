﻿using Microsoft.Bot.Builder;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Builder.Dialogs.Choices;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Threading;
using System.Threading.Tasks;

namespace NewWaterFallAdaptive.Dialogs.Forms
{
    public class FeedbackForm : ComponentDialog
    {
        private readonly IStatePropertyAccessor<User> _userAccessor;
        public FeedbackForm(UserState userState) : base(nameof(FeedbackForm))
        {
            _userAccessor = userState.CreateProperty<User>("User");

            var waterfallSteps = new WaterfallStep[]
            {                
                FeedbackOptionsAsync,
                FeedbackAsync,
                EmailIDAsync,                
               // ConfirmStepAsync,
                SummaryStepAsync,
            };

            AddDialog(new WaterfallDialog(nameof(WaterfallDialog), waterfallSteps));
            AddDialog(new TextPrompt(nameof(TextPrompt)));
            AddDialog(new NumberPrompt<int>(nameof(NumberPrompt<int>)));
            AddDialog(new ChoicePrompt(nameof(ChoicePrompt)));
            AddDialog(new ConfirmPrompt(nameof(ConfirmPrompt)));

            InitialDialogId = nameof(WaterfallDialog);
        }
        private static async Task<DialogTurnResult> FeedbackOptionsAsync(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {
            return await stepContext.PromptAsync(nameof(ChoicePrompt), new PromptOptions
            {
                Prompt = MessageFactory.Text("Can you spare few minutes to give your feedback?"),
                Choices = ChoiceFactory.ToChoices(new List<string> { "Sure", "Not Now" }),
            }, cancellationToken);
        }
        private static async Task<DialogTurnResult> FeedbackAsync(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {
            stepContext.Values["FeedbackOptions"] = ((FoundChoice)stepContext.Result).Value;

            if ((string)stepContext.Values["FeedbackOptions"] == "Sure")
            {
                return await stepContext.PromptAsync(nameof(TextPrompt), new PromptOptions
                {
                    Prompt = MessageFactory.Text("Please provide your Feedback.")
                }, cancellationToken);
            }
            else
            {
                return await stepContext.NextAsync(stepContext, cancellationToken);
            }
        }

        private static async Task<DialogTurnResult> EmailIDAsync(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {
            if ((string)stepContext.Values["FeedbackOptions"] == "Sure")
            {
                stepContext.Values["UserFeedback"] = (string)stepContext.Result;

                return await stepContext.PromptAsync(nameof(TextPrompt), new PromptOptions
                {
                    Prompt = MessageFactory.Text("Please provide your Email ID.")
                }, cancellationToken);
            }
            else
            {
                return await stepContext.NextAsync(stepContext, cancellationToken);
            }

        }
        private static async Task<DialogTurnResult> ConfirmStepAsync(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {
            stepContext.Values["UserEmailID"] = (string)stepContext.Result;

            return await stepContext.PromptAsync(nameof(ConfirmPrompt), new PromptOptions
            {
                Prompt = MessageFactory.Text("Would you like to Confirm?")
            }, cancellationToken);
        }
        private async Task<DialogTurnResult> SummaryStepAsync(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {
            if ((string)stepContext.Values["FeedbackOptions"] == "Sure")
            {
                stepContext.Values["UserEmailID"] = (string)stepContext.Result;
            //if ((bool)stepContext.Result)
            // {
            var user = await _userAccessor.GetAsync(stepContext.Context, () => new User(), cancellationToken);

                user.FeedbackOptions = (string)stepContext.Values["FeedbackOptions"];
                user.UserFeedback = (string)stepContext.Values["UserFeedback"];
                user.UserEmailID = (string)stepContext.Values["UserEmailID"];
            
                string baseUrl = "";
                HttpWebRequest request = (HttpWebRequest)WebRequest.Create(baseUrl);
                request.ContentType = "application/json";
                request.Method = "POST";

                string json = "{\"Requests\":{\"Request\":{" + "\"RequestSubCategory\":\"" + "Feedback" + "\","
           + "\"UserEmail\":\"" + user.UserEmailID + "\","
           + "\"Feedback\":\"" + user.UserFeedback + "\","
           + "}}}";

                using (var streamWriter = new StreamWriter(request.GetRequestStream()))
                {
                    streamWriter.Write(json);
                }
                await stepContext.Context.SendActivityAsync(MessageFactory.Text("Thank you for your feedback!"));
            }
            else if((string)stepContext.Values["FeedbackOptions"] == "Not Now")
            {
                await stepContext.Context.SendActivityAsync(MessageFactory.Text("Sorry to bother you." + Environment.NewLine + "Have a great day!"));
            }
                    //var response = request.GetResponse();
                //await stepContext.Context.SendActivityAsync(MessageFactory.Text("Thank you, Request is Confirmed."));

                //await stepContext.Context.SendActivityAsync(MessageFactory.Text(user.RequestOptions+ user.SiteName + user.SiteTemplate + user.ParentSiteURL + user.BusinessJustification));
           // }
          //  else
          //  {
          //      await stepContext.Context.SendActivityAsync(MessageFactory.Text("Request Not Confirmed."));
          //  }
            return await stepContext.EndDialogAsync(cancellationToken: cancellationToken);

        }
    }
}
