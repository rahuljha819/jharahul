﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Threading;
using Microsoft.Bot.Builder;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Builder.Dialogs.Choices;
using Newtonsoft.Json.Linq;
using System.IO;
using System.Net;

namespace NewWaterFallAdaptive.Dialogs.Forms
{
    public class DistributionListForm : ComponentDialog
    {
        private readonly IStatePropertyAccessor<User> _userAccessor;

        public DistributionListForm(UserState userAccessor) : base(nameof(DistributionListForm))
        {
            _userAccessor = userAccessor.CreateProperty<User>("User");
            var waterfallSteps = new WaterfallStep[]
            {
                RequestOptionAsync,
                ///*Confirm1Async*/,
                GroupMailboxDisplayNameAsync,
                GroupMailboxEmailAddressAsync,
                GroupMailboxOwnerAsync,
                AddOrRemoveAsync,
                AccessTypeAsync,
                ListOfUsersAsync,
                BusinessJustificationAsync,
                ConfirmStepAsync,
                SummaryStepAsync,
            };

            AddDialog(new WaterfallDialog(nameof(WaterfallDialog), waterfallSteps));
            AddDialog(new TextPrompt(nameof(TextPrompt)));
            AddDialog(new NumberPrompt<int>(nameof(NumberPrompt<int>)));
            AddDialog(new ChoicePrompt(nameof(ChoicePrompt)));
            AddDialog(new ConfirmPrompt(nameof(ConfirmPrompt)));

            InitialDialogId = nameof(WaterfallDialog);
        }       

        private static async Task<DialogTurnResult> RequestOptionAsync(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {
            return await stepContext.PromptAsync(nameof(ChoicePrompt), new PromptOptions
            {
                Prompt = MessageFactory.Text("Please choose your option for Distribution List request."),
                Choices = ChoiceFactory.ToChoices(new List<string> { "Create New", "Add/Remove User", "Delete" }),
            }, cancellationToken);
        }       

        private static async Task<DialogTurnResult> GroupMailboxDisplayNameAsync(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {
            stepContext.Values["RequestOptions"] = ((FoundChoice)stepContext.Result).Value;

            if ((string)stepContext.Values["RequestOptions"] == "Create New")
            {
                return await stepContext.PromptAsync(nameof(TextPrompt), new PromptOptions
                {
                    Prompt = MessageFactory.Text("Please enter the Distribution List Display name.")
                }, cancellationToken);
            }
            else
            {
                return await stepContext.NextAsync(stepContext, cancellationToken);
            }
        }

        private static async Task<DialogTurnResult> GroupMailboxEmailAddressAsync(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {
            if ((string)stepContext.Values["RequestOptions"] == "Create New")
            {
                stepContext.Values["GroupMailboxDisplayName"] = (string)stepContext.Result;

                //return await stepContext.PromptAsync(nameof(TextPrompt), new PromptOptions
                //{
                //    Prompt = MessageFactory.Text("Please enter the Distribution List Email Address.")
                //}, cancellationToken);
            }

            return await stepContext.PromptAsync(nameof(TextPrompt), new PromptOptions
            {
                Prompt = MessageFactory.Text("Please enter the Distribution List Email Address.")
            }, cancellationToken);

        }

        private static async Task<DialogTurnResult> GroupMailboxOwnerAsync(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {
            stepContext.Values["GroupMailboxEmailAddress"] = (string)stepContext.Result;

            if ((string)stepContext.Values["RequestOptions"] == "Create New")
            {
                return await stepContext.PromptAsync(nameof(TextPrompt), new PromptOptions
                {
                    Prompt = MessageFactory.Text("Please enter the Distribution List Owner Email Address.")
                }, cancellationToken);
            }
            else
            {
                return await stepContext.NextAsync(stepContext, cancellationToken);
            }
        }

        private static async Task<DialogTurnResult> AddOrRemoveAsync(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {
            if ((string)stepContext.Values["RequestOptions"] == "Create New")
            {
                stepContext.Values["GroupMailboxOwner"] = (string)stepContext.Result;
                return await stepContext.NextAsync(stepContext, cancellationToken);
            }

            if ((string)stepContext.Values["RequestOptions"] == "Add/Remove User")
            {
                return await stepContext.PromptAsync(nameof(ChoicePrompt), new PromptOptions
                {
                    Prompt = MessageFactory.Text("Do you want to Add or Remove user's permission."),
                    Choices = ChoiceFactory.ToChoices(new List<string> { "Add", "Remove" }),
                }, cancellationToken);
            }
            else
            {
                return await stepContext.NextAsync(stepContext, cancellationToken);
            }
        }

        private static async Task<DialogTurnResult> AccessTypeAsync(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {
            if ((string)stepContext.Values["RequestOptions"] == "Add/Remove User")
            {
                stepContext.Values["AddOrRemove"] = ((FoundChoice)stepContext.Result).Value;

                return await stepContext.PromptAsync(nameof(ChoicePrompt), new PromptOptions
                {
                    Prompt = MessageFactory.Text("Please choose access type."),
                    Choices = ChoiceFactory.ToChoices(new List<string> { "Owner", "Member", "Delegate With Send As Permission", "Delegate With Send On Behalf Permission" }),
                }, cancellationToken);
            }
            else
            {
                return await stepContext.NextAsync(stepContext, cancellationToken);
            }
        }

        private static async Task<DialogTurnResult> ListOfUsersAsync(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {
            if ((string)stepContext.Values["RequestOptions"] == "Add/Remove User")
            {
                stepContext.Values["AccessType"] = ((FoundChoice)stepContext.Result).Value;
            }

            else if ((string)stepContext.Values["RequestOptions"] == "Delete")
            {
                return await stepContext.NextAsync(stepContext, cancellationToken);
            }

            return await stepContext.PromptAsync(nameof(TextPrompt), new PromptOptions
            {
                Prompt = MessageFactory.Text("Please enter List of Member's Email Address.")
            }, cancellationToken);
        }
        private static async Task<DialogTurnResult> BusinessJustificationAsync(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {
            if ((string)stepContext.Values["RequestOptions"] != "Delete")
            {
                stepContext.Values["ListOfUsers"] = (string)stepContext.Result;
            }


            return await stepContext.PromptAsync(nameof(TextPrompt), new PromptOptions
            {
                Prompt = MessageFactory.Text("Please enter Business Justification.")
            }, cancellationToken);
        }

        private static async Task<DialogTurnResult> ConfirmStepAsync(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {
            stepContext.Values["BusinessJustification"] = (string)stepContext.Result;
            var requestDetails = "";


            if ((string)stepContext.Values["RequestOptions"] == "Create New")
            {
                requestDetails = "Do you want to create a Distribution List with following parameters: ";
                requestDetails = requestDetails + Environment.NewLine + "Distribution List Name: " + stepContext.Values["GroupMailboxDisplayName"];
                requestDetails = requestDetails + Environment.NewLine + "Distribution List Email Address: " + stepContext.Values["GroupMailboxEmailAddress"];
                requestDetails = requestDetails + Environment.NewLine + "Distribution List Owner: " + stepContext.Values["GroupMailboxOwner"];
                requestDetails = requestDetails + Environment.NewLine + "Distribution List Members: " + stepContext.Values["ListOfUsers"];
                requestDetails = requestDetails + Environment.NewLine + "Business Justification: " + stepContext.Values["BusinessJustification"];
            }
            if ((string)stepContext.Values["RequestOptions"] == "Add/Remove User")
            {
                requestDetails = "Do you want to modify a Distribution List with following parameters: ";
                requestDetails = requestDetails + Environment.NewLine + "Distribution List Email Address: " + stepContext.Values["GroupMailboxEmailAddress"];
                requestDetails = requestDetails + Environment.NewLine + "Distribution List Action: " + stepContext.Values["AddOrRemove"];
                requestDetails = requestDetails + Environment.NewLine + "Type of Access: " + stepContext.Values["AccessType"];
                requestDetails = requestDetails + Environment.NewLine + "Users List: " + stepContext.Values["ListOfUsers"];
                requestDetails = requestDetails + Environment.NewLine + "Business Justification: " + stepContext.Values["BusinessJustification"];
            }
            if ((string)stepContext.Values["RequestOptions"] == "Delete")
            {
                requestDetails = "Do you want to Delete the following Distribution List: ";
                requestDetails = requestDetails + Environment.NewLine + "Distribution List Email Address: " + stepContext.Values["GroupMailboxEmailAddress"];
                requestDetails = requestDetails + Environment.NewLine + "Business Justification: " + stepContext.Values["BusinessJustification"];
            }          


            return await stepContext.PromptAsync(nameof(ConfirmPrompt), new PromptOptions
            {
                Prompt = MessageFactory.Text(requestDetails + "Would you like to Confirm?")
            }, cancellationToken);
        }

        private async Task<DialogTurnResult> SummaryStepAsync(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {
            if ((bool)stepContext.Result)
            {
                var user = await _userAccessor.GetAsync(stepContext.Context, () => new User(), cancellationToken);

                user.RequestOptions = (string)stepContext.Values["RequestOptions"];

                if ((string)stepContext.Values["RequestOptions"] != "Delete")
                {
                    if ((string)stepContext.Values["RequestOptions"] == "Create New")
                    {
                        user.GroupMailboxDisplayName = (string)stepContext.Values["GroupMailboxDisplayName"];
                        user.GroupMailboxOwner = (string)stepContext.Values["GroupMailboxOwner"];
                    }


                    user.ListofUsers = (string)stepContext.Values["ListOfUsers"];

                    if ((string)stepContext.Values["RequestOptions"] == "AddOrRemove")
                    {
                        user.AccessType = (string)stepContext.Values["AccessType"];
                        user.AddOrRemove = (string)stepContext.Values["AddOrRemove"];
                    }
                }


                user.GroupMailboxEmailAddress = (string)stepContext.Values["GroupMailboxEmailAddress"];
                user.BusinessJustification = (string)stepContext.Values["BusinessJustification"];

                var msg = user.RequestOptions + user.GroupMailboxDisplayName + user.GroupMailboxEmailAddress + user.GroupMailboxOwner + user.AddOrRemove + user.AccessType + user.ListofUsers + user.BusinessJustification;

                string finalValue = "";

                string baseUrl = ""; //SNIntergationAPI;
                HttpWebRequest request = (HttpWebRequest)WebRequest.Create(baseUrl);
                request.ContentType = "application/json";
                request.Method = "POST";
                
                if (user.RequestOptions == "Create New")
                {
                    user.RequestOptions = "create_a_new_group_mailbox";
                }
                else if (user.RequestOptions == "Add/Remove User")
                {
                    user.RequestOptions = "add_remove_user_from_a_group_mailbox";
                }
                else if (user.RequestOptions == "Delete")
                {
                    user.RequestOptions = "delete_a_group_mailbox";
                }
                
                if (user.AddOrRemove == "Add")
                {
                    user.AddOrRemove = "add_users";
                }
                else if (user.AddOrRemove == "Remove")
                {
                    user.AddOrRemove = "remove_users";
                }
                
                if (user.AccessType == "Owner")
                {
                    user.AccessType = "owner";
                }
                else if (user.AccessType == "Member")
                {
                    user.AccessType = "member";
                }
                else if (user.AccessType == "Delegate With Send As Permission")
                {
                    user.AccessType = "delegate_with_send_as_permission";
                }
                else if (user.AccessType == "Delegate With Send On Behalf Permission")
                {
                    user.AccessType = "delegate_with_send_on_behalf_permission";
                }

                string json = "{\"item_name\":\"" + "Mailbox" + "\","
                    + "\"select_options\":\"" + user.RequestOptions + "\","
                    + "\"add_or_remove_user_permission_from_group_mailbox\":\"" + user.AddOrRemove + "\","
                    + "\"group_mailbox_display_name\":\"" + user.GroupMailboxDisplayName + "\","
                    + "\"group_mailbox_email_address\":\"" + user.GroupMailboxEmailAddress + "\","
                    + "\"group_mailbox_owner\":\"" + user.GroupMailboxOwner + "\","
                    + "\"type_of_access\":\"" + user.AccessType + "\","
                    + "\"provide_list_of_users_email_address_or_network_id\":\"" + user.ListofUsers + "\","
                    + "\"business_justification\":\"" + user.BusinessJustification + "\""
                    + "}";

                using (var streamWriter = new StreamWriter(request.GetRequestStream()))
                {
                    streamWriter.Write(json);
                }

                using (var response = (HttpWebResponse)request.GetResponse())
                {
                    string responseValue = "";

                    if (response.StatusCode != HttpStatusCode.Created)
                    {
                        var message = String.Format("Request failed. Received HTTP {0}", response.StatusCode);
                        throw new ApplicationException(message);
                    }

                    // grab the response
                    using (var responseStream = response.GetResponseStream())
                    {
                        if (responseStream != null)
                            using (var reader = new StreamReader(responseStream))
                            {
                                responseValue = reader.ReadToEnd();
                            }

                    }
                    JObject obj = JObject.Parse(responseValue);

                    var requestValues = JObject.FromObject(obj).ToObject<Dictionary<string, object>>();

                    foreach (KeyValuePair<string, object> reqVal in requestValues)
                    {
                        var requestObject = JObject.FromObject(requestValues).ToObject<Dictionary<string, string>>();
                        foreach (KeyValuePair<string, string> reqValue in requestObject)
                        {
                            finalValue = reqValue.Value;
                        }
                    }
                }
               // await stepContext.Context.SendActivityAsync(MessageFactory.Text(msg));
                await stepContext.Context.SendActivityAsync(MessageFactory.Text("Thank you for the inputs. Your Ticket No. is: " + finalValue));

            }
            else
            {
                await stepContext.Context.SendActivityAsync(MessageFactory.Text("Request Not Confirmed."));
            }
            return await stepContext.EndDialogAsync(cancellationToken: cancellationToken);
        }
    }
}
