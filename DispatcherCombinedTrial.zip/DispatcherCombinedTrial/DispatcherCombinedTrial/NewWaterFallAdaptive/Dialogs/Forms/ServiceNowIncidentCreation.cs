﻿using Microsoft.Bot.Builder;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Builder.Dialogs.Choices;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace NewWaterFallAdaptive.Dialogs.Forms
{
    public class ServiceNowIncidentCreation : ComponentDialog
    {
        private readonly IStatePropertyAccessor<User> _userAccessor;

        public ServiceNowIncidentCreation(UserState userAccessor) : base(nameof(ServiceNowIncidentCreation))
        {
            _userAccessor = userAccessor.CreateProperty<User>("User");
            var waterfallSteps = new WaterfallStep[]
            {
                ServiceNowIncidentCreationOptionsAsync,
                ServiceNowSiteURLAsync,
                ServiceNowShortDescriptionAsync,
               // ConfirmStepAsync,
                SummaryStepAsync,
            };

            AddDialog(new WaterfallDialog(nameof(WaterfallDialog), waterfallSteps));
            AddDialog(new TextPrompt(nameof(TextPrompt)));
            AddDialog(new NumberPrompt<int>(nameof(NumberPrompt<int>)));
            AddDialog(new ChoicePrompt(nameof(ChoicePrompt)));
            AddDialog(new ConfirmPrompt(nameof(ConfirmPrompt)));

            InitialDialogId = nameof(WaterfallDialog);
        }
        private static async Task<DialogTurnResult> ServiceNowIncidentCreationOptionsAsync(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {
            return await stepContext.PromptAsync(nameof(ChoicePrompt), new PromptOptions
            {
                Prompt = MessageFactory.Text("You can report any migration issue by creating a ticket in ServiceNow.\nDo you wish to create a ticket now?"),
                Choices = ChoiceFactory.ToChoices(new List<string> { "Yes", "No" }),
            }, cancellationToken);
        }
        private static async Task<DialogTurnResult> ServiceNowSiteURLAsync(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {
            stepContext.Values["ServiceNowTicketCreationOptions"] = ((FoundChoice)stepContext.Result).Value;

            if ((string)stepContext.Values["ServiceNowTicketCreationOptions"] == "Yes")
            {
                return await stepContext.PromptAsync(nameof(TextPrompt), new PromptOptions
                {
                    Prompt = MessageFactory.Text("Please provide site URL where you are facing issue")
                }, cancellationToken);
            }
            else
            {
                return await stepContext.NextAsync(stepContext, cancellationToken);
            }
        }

        private static async Task<DialogTurnResult> ServiceNowShortDescriptionAsync(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {
            if ((string)stepContext.Values["ServiceNowTicketCreationOptions"] == "Yes")
            {
                stepContext.Values["ServiceNowSiteURL"] = (string)stepContext.Result;

                return await stepContext.PromptAsync(nameof(TextPrompt), new PromptOptions
                {
                    Prompt = MessageFactory.Text("Please provide short description.")
                }, cancellationToken);
            }
            else
            {
                return await stepContext.NextAsync(stepContext, cancellationToken);
            }

        }
        private static async Task<DialogTurnResult> ConfirmStepAsync(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {
            stepContext.Values["ServiceNowShortDescription"] = (string)stepContext.Result;

            return await stepContext.PromptAsync(nameof(ConfirmPrompt), new PromptOptions
            {
                Prompt = MessageFactory.Text("Would you like to Confirm?")
            }, cancellationToken);
        }

        private async Task<DialogTurnResult> SummaryStepAsync(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {
            if ((string)stepContext.Values["ServiceNowTicketCreationOptions"] == "Yes")
            {
                stepContext.Values["ServiceNowShortDescription"] = (string)stepContext.Result;
                var user = await _userAccessor.GetAsync(stepContext.Context, () => new User(), cancellationToken);

                user.ServiceNowSiteURL = (string)stepContext.Values["ServiceNowSiteURL"];
                user.ServiceNowDescription = (string)stepContext.Values["ServiceNowShortDescription"];

                // var msg = user.ServiceNowSiteURL + user.ServiceNowDescription;
                string username = "";
                string password = "";
                string url = "";

                var auth = "Basic " + Convert.ToBase64String(Encoding.Default.GetBytes(username + ":" + password));

                HttpWebRequest request = WebRequest.Create(url) as HttpWebRequest;
                request.Headers.Add("Authorization", auth);
                request.Method = "Post";

                string json = "";
                using (var streamWriter = new StreamWriter(request.GetRequestStream()))
                {
                    json = JsonConvert.SerializeObject(new
                    {
                        short_description = "Migration issue with URL: " + user.ServiceNowSiteURL + ";User Comments: " + user.ServiceNowDescription,
                        caller_id = "admin"
                    });

                    streamWriter.Write(json);
                }

                using (HttpWebResponse response = request.GetResponse() as HttpWebResponse)
                {
                    var res = new StreamReader(response.GetResponseStream()).ReadToEnd();
                    //await context.PostAsync(res);
                    JObject joResponse = JObject.Parse(res.ToString());
                    JObject ojObject = (JObject)joResponse["result"];
                    string incNumber = ((JValue)ojObject.SelectToken("number")).Value.ToString();
                    await stepContext.Context.SendActivityAsync(MessageFactory.Text("Your issue has been reported. Kindly note down the ticket number: " + incNumber));
                    //return incNumber;
                }

                //await stepContext.Context.SendActivityAsync(MessageFactory.Text("Request Confirmed. Inputs are " + msg));
                return await stepContext.EndDialogAsync(user, cancellationToken);
            }
            else if ((string)stepContext.Values["ServiceNowTicketCreationOptions"] == "No")
            {
                await stepContext.Context.SendActivityAsync(MessageFactory.Text("Sorry to bother you." + Environment.NewLine + "Have a great day!"));
            }

            //}
            //else
            //{
            //    await stepContext.Context.SendActivityAsync(MessageFactory.Text("Request Not Confirmed."));
                return await stepContext.EndDialogAsync(cancellationToken: cancellationToken);
            //}

        }
    }
}
