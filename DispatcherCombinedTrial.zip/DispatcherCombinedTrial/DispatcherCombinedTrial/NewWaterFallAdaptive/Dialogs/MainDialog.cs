// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License.
//
// Generated with Bot Builder V4 SDK Template for Visual Studio CoreBot v4.3.0

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using AdaptiveCards;
using Microsoft.Bot.Builder;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Builder.Dialogs.Choices;
using Microsoft.Bot.Schema;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Microsoft.Recognizers.Text.DataTypes.TimexExpression;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using NewWaterFallAdaptive.Dialogs.Forms;

namespace NewWaterFallAdaptive.Dialogs
{
    public class MainDialog : ComponentDialog
    {
        protected readonly IConfiguration Configuration;
        protected readonly ILogger Logger;

        public string CHOICEPROMPT { get; private set; }

        public MainDialog(UserState userState) : base(nameof(MainDialog))
        {
            //_userAccessor = userState.CreateProperty<User>("User");

            //var waterfallSteps = new WaterfallStep[]
            WaterfallStep[] waterfallSteps = new WaterfallStep[]
            {
                //PromptWithAdaptiveCardAsync,
               // DisplayCardAsync,
               // ActStepAsync,
                //HandleResponseAsync,
                //HandleServiceNowResponseAsync,
                //IntroStepAsync,
               ActStepAsync,

            };

            AddDialog(new WaterfallDialog(nameof(WaterfallDialog), waterfallSteps));
            AddDialog(new TextPrompt(nameof(TextPrompt)));
            AddDialog(new NumberPrompt<int>(nameof(NumberPrompt<int>)));
            AddDialog(new ChoicePrompt(nameof(ChoicePrompt)));
            AddDialog(new ConfirmPrompt(nameof(ConfirmPrompt)));
            AddDialog(new DistributionListForm(userState));
            AddDialog(new CreateTeamForm(userState));
            AddDialog(new RequestForm(userState));
            InitialDialogId = nameof(WaterfallDialog);
        }

        private async Task<DialogTurnResult> IntroStepAsync(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {
            if (string.IsNullOrEmpty(Configuration["LuisAppId"]) || string.IsNullOrEmpty(Configuration["LuisAPIKey"]) || string.IsNullOrEmpty(Configuration["LuisAPIHostName"]))
            {
                await stepContext.Context.SendActivityAsync(
                    MessageFactory.Text("NOTE: LUIS is not configured. To enable all capabilities, add 'LuisAppId', 'LuisAPIKey' and 'LuisAPIHostName' to the appsettings.json file."), cancellationToken);

                return await stepContext.NextAsync(null, cancellationToken);
            }
            else
            {
                return await stepContext.PromptAsync(nameof(TextPrompt), new PromptOptions { Prompt = MessageFactory.Text("What can I help you with today?") }, cancellationToken);
            }
        }

        private async Task<DialogTurnResult> ActStepAsync(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {
            //Call LUIS and gather any potential booking details. (Note the TurnContext has the response to the prompt.)
            // var userDetails = stepContext.Result != null
            //   ?
            // await LuisHelper.ExecuteLuisQuery(Configuration, Logger, stepContext.Context, cancellationToken)
            //:
            //new User();


            //var userSelection = stepContext.Result;
            //if (userSelection.ToString() == "Site Provisioning Request")
            //{
            //    return await stepContext.BeginDialogAsync(nameof(RequestForm), cancellationToken);
            //}
            //else if (userSelection.ToString() == "License Request")
            //{

            //    return await stepContext.BeginDialogAsync(nameof(LicenseRequestForm), cancellationToken);
            //}
            //else if (userSelection.ToString() == "Create Team Form")
            //{

            //    return await stepContext.BeginDialogAsync(nameof(CreateTeamForm), cancellationToken);
            //}

            return await stepContext.BeginDialogAsync(nameof(RequestForm),null, cancellationToken);
            // return await stepContext.NextAsync(null, cancellationToken);
            //    // In this sample we only have a single Intent we are concerned with. However, typically a scenario
            //    // will have multiple different Intents each corresponding to starting a different child Dialog.

            //    // Run the BookingDialog giving it whatever details we have from the LUIS call, it will fill out the remainder.
            //    // return await stepContext.BeginDialogAsync(nameof(BookingDialog), bookingDetails, cancellationToken);
        }

        private async Task<DialogTurnResult> FinalStepAsync(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {
            // If the child dialog ("BookingDialog") was cancelled or the user failed to confirm, the Result here will be null.
            if (stepContext.Result != null)
            {
                var result = (User)stepContext.Result;

                // Now we have all the booking details call the booking service.

                // If the call to the booking service was successful tell the user.

                //var timeProperty = new TimexProperty(result.TravelDate);
                //var travelDateMsg = timeProperty.ToNaturalLanguage(DateTime.Now);
                var msg = $"thank u";
                await stepContext.Context.SendActivityAsync(MessageFactory.Text(msg), cancellationToken);
            }
            else
            {
                await stepContext.Context.SendActivityAsync(MessageFactory.Text("Thank you."), cancellationToken);
            }
            return await stepContext.EndDialogAsync(cancellationToken: cancellationToken);
        }
    }
}
