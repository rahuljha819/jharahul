// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License.
//
// Generated with Bot Builder V4 SDK Template for Visual Studio CoreBot v4.3.0

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Azure.CognitiveServices.Language.LUIS.Runtime.Models;
using Microsoft.Bot.Builder;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Schema;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Microsoft.SharePoint.Client;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using NewWaterFallAdaptive.Dialogs;
using NewWaterFallAdaptive.Dialogs.Forms;

namespace NewWaterFallAdaptive.Bots
{
    // This IBot implementation can run any type of Dialog. The use of type parameterization is to allows multiple different bots
    // to be run at different endpoints within the same project. This can be achieved by defining distinct Controller types
    // each with dependency on distinct IBot types, this way ASP Dependency Injection can glue everything together without ambiguity.
    // The ConversationState is used by the Dialog system. The UserState isn't, however, it might have been used in a Dialog implementation,
    // and the requirement is that all BotState objects are saved at the end of a turn.
    public class DialogBot<T> : ActivityHandler where T : Dialog
    {
        protected readonly Dialog Dialog;
        //protected readonly BotState ConversationState;
        protected readonly BotState UserState;
        protected readonly ILogger Logger;
        private IBotServices BotServices;
        private IEnumerable<WaterfallStep> waterfallSteps;
        private ConversationState ConversationState;

        //private DialogSet _dialogs;
        private DialogSet Dialogs { get; set; }
       // private IConfiguration configuration;



        public DialogBot(IBotServices botServices, ConversationState conversationState, UserState userState, T dialog, ILogger<DialogBot<T>> logger)
        {
            ConversationState = conversationState;
            UserState = userState;
            Dialog = dialog;
            Logger = logger;
            BotServices = botServices;
           // RegisterDialogs();
            Dialogs = new DialogSet(conversationState.CreateProperty<DialogState>(nameof(DialogBot<T>)));
            RegisterDialogs(Dialogs);
            
            Dialogs.Add(new WaterfallDialog("MainDialog", new WaterfallStep[]
            {
            async (dc, cancellationToken) =>
            {
            // Start the ChoiceFlowDialog that was loaded earlier
            // This will take the conversation through the 
            // 'waterfall' steps defined in the choiceFlow.json file
                return await dc.BeginDialogAsync(nameof(RequestForm));
            }
            }));
            
        }

        public override async Task OnTurnAsync(ITurnContext turnContext, CancellationToken cancellationToken = default(CancellationToken))
        {
            await base.OnTurnAsync(turnContext, cancellationToken);
            var activity = turnContext.Activity;

            if (string.IsNullOrWhiteSpace(activity.Text))
            //if (string.IsNullOrWhiteSpace(activity.Text))
            {
                activity.Text = JsonConvert.SerializeObject(activity.Text);
            }            
            await ConversationState.SaveChangesAsync(turnContext, false, cancellationToken);
            await UserState.SaveChangesAsync(turnContext, false, cancellationToken);
        }

        //protected override async Task OnMembersAddedAsync(IList<ChannelAccount> membersAdded, ITurnContext<IConversationUpdateActivity> turnContext, CancellationToken cancellationToken)
        //{
        //    const string WelcomeText = "Type a greeting, or a question about the weather to get started.";

        //    foreach (var member in membersAdded)
        //    {
        //        if (member.Id != turnContext.Activity.Recipient.Id)
        //        {
        //            await turnContext.SendActivityAsync(MessageFactory.Text($"Welcome to Dispatch bot {member.Name}. {WelcomeText}"), cancellationToken);
        //        }
        //    }
        //}

        protected override async Task OnMessageActivityAsync(ITurnContext<IMessageActivity> turnContext, CancellationToken cancellationToken)
        {
            //var routeResult = EndOfTurn;
            // First, we use the dispatch model to determine which cognitive service (LUIS or QnA) to use.
            var recognizerResult = await BotServices.Dispatch.RecognizeAsync(turnContext, cancellationToken);

            // Top intent tell us which cognitive service to use.
            var topIntent = recognizerResult.GetTopScoringIntent();

            // Next, we call the dispatcher with the top intent.
            await DispatchToTopIntentAsync(turnContext, topIntent.intent, recognizerResult, cancellationToken);

            //await Dialog.RunAsync(turnContext, ConversationState.CreateProperty<DialogState>(nameof(MainDialog)), cancellationToken);

        }
        
           // Dialogs = new DialogSet(ConversationState.CreateProperty<DialogState>(nameof(DialogBot<T>)));
            
           
        private void RegisterDialogs(DialogSet dialogs)
        {
           Dialogs.Add(new WaterfallDialog("CreateTeamForm", waterfallSteps));
            Dialogs.Add(new WaterfallDialog("DistributionListForm", waterfallSteps));
            Dialogs.Add(new WaterfallDialog("FeedbackForm", waterfallSteps));
            Dialogs.Add(new WaterfallDialog("LicenseRequestForm", waterfallSteps));
            Dialogs.Add(new WaterfallDialog("MailboxAccessForm", waterfallSteps));
            Dialogs.Add(new WaterfallDialog("RequestForm", waterfallSteps));
            Dialogs.Add(new WaterfallDialog("ServiceNowIncidentCreation", waterfallSteps));
            Dialogs.Add(new WaterfallDialog("SharedMailboxForm", waterfallSteps));
        }

        private async Task DispatchToTopIntentAsync(ITurnContext<IMessageActivity> turnContext, string intent, RecognizerResult recognizerResult, CancellationToken cancellationToken)
        {
            switch (intent)
            {
                case "snow_training":
                    //var msg = $"Please provide the search query details";
                    //await turnContext.SendActivityAsync(MessageFactory.Text(msg), cancellationToken);
                    await SnowAndTraining(turnContext, recognizerResult.Properties["luisResult"] as LuisResult, cancellationToken);

                    break;
                case "qna":                   
                    await QnAAsync(turnContext, cancellationToken);

                    break;
                default:
                    Logger.LogInformation($"Dispatch unrecognized intent: {intent}.");
                    //await turnContext.SendActivityAsync(MessageFactory.Text($"Dispatch unrecognized intent: {intent}."), cancellationToken);
                    break;
            }
        }

        private async Task SnowAndTraining(ITurnContext<IMessageActivity> turnContext, LuisResult luisResult, CancellationToken cancellationToken)
        {
            Logger.LogInformation("SnowAndTraining");

            // Retrieve LUIS result for Process Automation.
            var result = luisResult.ConnectedServiceResult;
            var topIntent = result.TopScoringIntent.Intent;
            
            var dc = await Dialogs.CreateContextAsync(turnContext);

            if (topIntent == "SearchTraining")
            {
                var entity = result.Entities;
                var courseName = "";
                var location = "";
                var dateTime = "";
                var mode = "";
                var user = new User();

                if (entity.Count > 0)
                {
                    if (entity[0].Entity != null)
                    {
                        courseName = entity[0].Entity.ToString();
                    }
                    else
                    {
                        courseName = "";
                    }
                    if(entity[1].Entity!=null)
                    {
                        location = entity[1].Entity.ToString();
                    }
                    else
                    {
                        location = "";
                    }
                    
                    
                    //dateTime = entity[3].Entity.ToString();

                }
                var LSSiteURL = "";
                var LSUserName = "";
                var LSUserPwd = "";

                string searchQuery = "";
                List<String> queries = new List<String>();
                user.Location = location;
                user.CourseName = courseName;
                SearchClass searchClass = new SearchClass();
                ClientContext ctx = searchClass.GetSPContext(LSSiteURL, LSUserName, LSUserPwd);
                if (user.CourseName != null)
                {
                    string temp = searchClass.GetCourseNameQuery(user.CourseName);
                    queries.Add(temp);
                }
                else if (user.Location != null)
                {
                    string temp = searchClass.GetLocationQuery(user.Location);
                    queries.Add(temp);
                }
                if (queries.Count > 1)
                {
                    string query = "<AND>";
                    foreach (string q in queries)
                    {
                        query = query + q;
                    }
                    searchQuery = query + "</AND>";
                }
                else if (queries.Count == 1)
                {
                    searchQuery = queries[0];
                }

                var querySearch = searchClass.SearchCourse(ctx, searchQuery);
                if (querySearch.Count == 0)
                {
                    var msg = $"OOPS! No trainings found. Try with different keywords...";
                    await turnContext.SendActivityAsync(MessageFactory.Text(msg), cancellationToken);
                    //await ctx.PostAsync($"OOPS! No trainings found. Try with different keywords...");
                }
                else
                {
                    await turnContext.SendActivityAsync(MessageFactory.Text($"I have found {querySearch.Count} training(s) based on your search query. Happy Learning!"), cancellationToken);

                    var card = new HeroCard();
                    foreach (ListItem listItem in querySearch)
                    {
                        string title = listItem["Title"].ToString();
                        string shortDesc = "";
                        string description = listItem["Description"].ToString();
                        if (description.Length > 60)
                        {
                            shortDesc = description.Substring(0, 150) + "...";
                        }
                        else
                        {
                            shortDesc = description;
                        }

                        var id = listItem["ID"];
                        //var mode = listItem["Mode"];
                        string startDate = listItem["EventDate"].ToString();
                        string finalDate = startDate.Split(' ')[0];

                        card.Title = title;
                        card.Subtitle = mode + " Training \n" + "Date: " + finalDate.ToString();
                        card.Text = shortDesc;
                        card.Buttons = new List<CardAction>
                                    {
                                        new CardAction(ActionTypes.OpenUrl, "View Training Details", value: "https://trainingslatest.azurewebsites.net/Pages/Details.aspx?SPHostUrl=https://infyakash.sharepoint.com/sites/SolutionsSite&SPAppWebUrl=https://InfyAkash-75e0d9f24e99f2.sharepoint.com/sites/SolutionsSite/Trainings_V2&Title="+title.ToString()+"&Id="+id+"&CapLimit=&Mode=Virtual&SiteURL=&ListName=Trainings&RegisterationList=Training%20Registeration")
                                    };
                        card.Images = new List<CardImage> { new CardImage("https://thumb9.shutterstock.com/display_pic_with_logo/2117717/331399106/stock-photo-training-skill-develop-ability-expertise-concept-331399106.jpg") };


                        var reply = MessageFactory.Attachment(card.ToAttachment());
                        await turnContext.SendActivityAsync(reply, cancellationToken);
                    }
                }
            }

            if (topIntent == "NewRequest")
            {
                //await NewRequestAsync(dc, cancellationToken);
                //var activity = turnContext.Activity;
                //activity.Text = "NewRequest";
                //await ConversationState.SaveChangesAsync(turnContext, false, cancellationToken);
                //await UserState.SaveChangesAsync(turnContext, false, cancellationToken);
               await dc.BeginDialogAsync(nameof(RequestForm));
                //await dc.BeginDialogAsync("RequestForm",null,cancellationToken);
            }

            else if(topIntent == "Mailbox")
            {
                await MaiboxAsync(dc, cancellationToken);
            }

            else if(topIntent == "DistributionList")
            {
                await DistributionListAsync(dc, cancellationToken);
            }
            else if(topIntent== "TeamsCreation")
            {
                await TeamsCreationAsync(dc, cancellationToken);
            }
            else if(topIntent == "IncidentCreation")
            {
                await IncidentCreationAsync(dc, cancellationToken);
            }
            else if(topIntent== "LicenseRequest")
            {
                await LicenseRequestAsync(dc, cancellationToken);
            }
            else if(topIntent == "SharedMailbox")
            {
                await SharedMailboxAsync(dc, cancellationToken);
            }
            else if(topIntent== "Greetings")
            {
                await GreetingsAsync(dc, cancellationToken);
            }

            //await turnContext.SendActivityAsync(MessageFactory.Text($"SnowAndTraining top intent {topIntent}."), cancellationToken);
            //await turnContext.SendActivityAsync(MessageFactory.Text($"HomeAutomation intents detected:\n\n{string.Join("\n\n", result.Intents.Select(i => i.Intent))}"), cancellationToken);
            if (result.Entities.Count > 0)
            {               
                await turnContext.SendActivityAsync(MessageFactory.Text($"SnowAndTraining entities were found in the message:\n\n{string.Join("\n\n", result.Entities.Select(i => i.Type))}"), cancellationToken);
                
            }

            await Dialog.RunAsync(turnContext, ConversationState.CreateProperty<DialogState>(nameof(DialogState)), cancellationToken);
            //await ConversationState.SaveChangesAsync(turnContext, false, cancellationToken);
            //await UserState.SaveChangesAsync(turnContext, false, cancellationToken);
        }

        protected async Task NewRequestAsync(DialogContext dc, CancellationToken cancellationToken = default(CancellationToken))
        {
            await dc.BeginDialogAsync(nameof(RequestForm));
        }

        protected async Task MaiboxAsync(DialogContext dc, CancellationToken cancellationToken = default(CancellationToken))
        {
            await dc.BeginDialogAsync(nameof(MailboxAccessForm));
        }

        protected async Task DistributionListAsync(DialogContext dc, CancellationToken cancellationToken = default(CancellationToken))
        {
            await dc.BeginDialogAsync(nameof(DistributionListForm));
        }

        protected async Task TeamsCreationAsync(DialogContext dc, CancellationToken cancellationToken = default(CancellationToken))
        {
            await dc.BeginDialogAsync(nameof(CreateTeamForm));
        }

        protected async Task IncidentCreationAsync(DialogContext dc, CancellationToken cancellationToken = default(CancellationToken))
        {
            await dc.BeginDialogAsync(nameof(ServiceNowIncidentCreation));
        }

        protected async Task LicenseRequestAsync(DialogContext dc, CancellationToken cancellationToken = default(CancellationToken))
        {
            await dc.BeginDialogAsync(nameof(LicenseRequestForm));
        }

        protected async Task SharedMailboxAsync(DialogContext dc, CancellationToken cancellationToken = default(CancellationToken))
        {
            await dc.BeginDialogAsync(nameof(SharedMailboxForm));
        }

        protected async Task GreetingsAsync(DialogContext dc, CancellationToken cancellationToken = default(CancellationToken))
        {
            await dc.BeginDialogAsync(nameof(FeedbackForm));
        }


        private async Task QnAAsync(ITurnContext<IMessageActivity> turnContext, CancellationToken cancellationToken)
        {
            Logger.LogInformation("QnAAsync");

            var results = await BotServices.SampleQnA.GetAnswersAsync(turnContext);
            if (results.Any())
            {
                await turnContext.SendActivityAsync(MessageFactory.Text(results.First().Answer), cancellationToken);
            }
            else
            {
                await turnContext.SendActivityAsync(MessageFactory.Text("I'm sorry but I'm unable to answer you on this."), cancellationToken);
            }
        }
    }
}
